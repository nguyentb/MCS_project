package org.com.user;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.com.recommendation.jpa.user.DurationType;
import org.com.recommendation.jpa.user.MovieContext;
import org.com.recommendation.jpa.user.MovieCountryTerms;
import org.com.recommendation.jpa.user.MovieDuration;
import org.com.recommendation.jpa.user.MovieGenre;
import org.com.recommendation.jpa.user.MovieLanguage;
import org.com.recommendation.jpa.user.MovieReleaseDate;
import org.com.recommendation.jpa.user.MusicContext;
import org.com.recommendation.jpa.user.MusicCountryTerms;
import org.com.recommendation.jpa.user.MusicDuration;
import org.com.recommendation.jpa.user.MusicGenre;
import org.com.recommendation.jpa.user.MusicLanguage;
import org.com.recommendation.jpa.user.MusicReleaseDate;
import org.com.recommendation.jpa.user.NewsContext;
import org.com.recommendation.jpa.user.NewsCountryTerms;
import org.com.recommendation.jpa.user.NewsGenre;
import org.com.recommendation.jpa.user.NewsLanguage;
import org.com.recommendation.jpa.user.NewsScopes;
import org.com.recommendation.jpa.user.NewsSources;
import org.com.recommendation.jpa.user.ReleaseDateType;
import org.com.recommendation.modifiedprofile.Context;
import org.com.recommendation.modifiedprofile.Country;
import org.com.recommendation.modifiedprofile.Duration;
import org.com.recommendation.modifiedprofile.Genre;
import org.com.recommendation.modifiedprofile.Language;
import org.com.recommendation.modifiedprofile.MovieTerms;
import org.com.recommendation.modifiedprofile.MusicTerms;
import org.com.recommendation.modifiedprofile.NewsTerms;
import org.com.recommendation.modifiedprofile.ReleaseDate;
import org.com.recommendation.modifiedprofile.Scope;
import org.com.recommendation.modifiedprofile.Source;
import org.com.recommendation.modifiedprofile.Term;
import org.com.recommendation.modifiedprofile.UserInformation;
import org.com.recommendation.modifiedprofile.User;

public class UserProfilePersist {
	static Context context;
	static Country country;
	static Duration duration;
	static Genre genre;
	static Language language;
	static ReleaseDate releaseDate;
	static MusicTerms musicTerms;
	static MovieTerms movieTerms;
	static NewsTerms newsTerms;
	static Scope scope;
	static Source source;
	static User user;
	
	static File file = new File("xml/ModifiedUserProfile.xml");
	
	static org.com.recommendation.jpa.user.User userData;
	

	@PersistenceContext
	static EntityManagerFactory emf = Persistence.createEntityManagerFactory("GrabMovies");
	static EntityManager em = emf.createEntityManager();
	static EntityTransaction tx = em.getTransaction();

    public static List<User> getUsers(File file) throws JAXBException {
	JAXBContext jaxb = JAXBContext
			.newInstance("org.com.recommendation.modifiedprofile");
	Unmarshaller unMarsharller = jaxb.createUnmarshaller();

	// File file;

	UserInformation userInformation = (UserInformation) unMarsharller
			.unmarshal(file);

	// List<User>userList = userList =
	return userInformation.getUser();

	// return userList;
	// new ArrayList<User>();
    }

	public static void main(String[] args) {
		try {

			List<User> userList = getUsers(file);

			System.out.println("Retrieving user profile data...");
			System.out.println();

			for (int i = 0; i < userList.size(); i++) {
				user = userList.get(i);

				User user = userList.get(i);
				System.out.println("User Id:" + user.getUserId()
						+ "User First Name : " + user.getFirstName()+ "User Last Name : " + user.getLastName() + " User Role: "
						+ user.getRole() + " User Age: " + user.getAge()
						+ " Nationality: " + user.getNationality());
				int userId = user.getUserId();
				String firstName = user.getFirstName();
				String lastName = user.getLastName();
				String gender = user.getGender();
				String role = user.getRole();
				int age = user.getAge();
				String nationality = user.getNationality();
				
				userData =   new org.com.recommendation.jpa.user.User(userId,firstName,lastName, age,gender,role, nationality);

				movieTerms = user.getMovieTerms();
				musicTerms = user.getMusicTerms();
				newsTerms = user.getNewsTerms();
				Genre genre = movieTerms.getGenre();
				Country country = movieTerms.getCountry();
				Duration duration = movieTerms.getDuration();
				Language language = movieTerms.getLanguage();
				ReleaseDate releaseDate = movieTerms.getReleaseDate();
				List<Context> contextList = movieTerms.getContext();

				Genre musicGenre = musicTerms.getGenre();
				Country musicCountry = musicTerms.getCountry();
				Duration musicDuration = musicTerms.getDuration();
				Language musicLanguage = musicTerms.getLanguage();
				ReleaseDate musicReleaseDate = musicTerms.getReleaseDate();
				// musicReleaseDate.
				List<Context> musicContextList = musicTerms.getContext();

				Genre newsGenre = newsTerms.getGenre();
				Country newsCountry = newsTerms.getCountry();
				//Duration newsDuration = newsTerms..getDuration();
				Language newsLanguage = newsTerms.getLanguage();
				Scope newsScope = newsTerms.getScope();
				Source newsSource = newsTerms.getSource();

				List<Context> newsContextList = newsTerms.getContext();
				List<Double> movieVector = new ArrayList<Double>();

				System.out.println();

				System.out.println("News Terms");

				System.out.println();

				for (Term term : newsGenre.getTerm()) {
					System.out.println("Genre " + term.getContent()
							+ "  Preference " + term.getWeight());
					
					NewsGenre newsgenre = new NewsGenre();
					String genre1 = term.getContent();
					double weight = term.getWeight();

					
					newsgenre.setGenre(genre1);
					newsgenre.setWeight(weight);
					userData.addNewsGenre(newsgenre);

				}

				// Term term = (Term)country.getTerm();

				for (Term term : newsCountry.getTerm()) {
					System.out.println("Country " + term.getContent()
							+ "  Preference " + term.getWeight());
					String country1 = term.getContent();
					double weight = term.getWeight();
					NewsCountryTerms countryTerm = new NewsCountryTerms();
					countryTerm.setCountry(country1);
					countryTerm.setWeight(weight);
					userData.addNewsCountryTerms(countryTerm);
				}

				for (Term term : newsScope.getTerm()) {
					System.out.println("Scope " + term.getContent()
							+ " Preference " + term.getWeight());

					String scope1 = term.getContent();
					double weight = term.getWeight();
					NewsScopes scopes = new NewsScopes();
					scopes.setScope(scope1);
					scopes.setWeight(weight);
					userData.addNewsScopes(scopes);

				}

				for (Term term : newsLanguage.getTerm()) {
					System.out.println("Language " + term.getContent()
							+ "  Preference " + term.getWeight());
					String lang = term.getContent();
					double weight = term.getWeight();
					NewsLanguage language1 = new NewsLanguage();
					language1.setLanguage(lang);
					language1.setWeight(weight);
					userData.addNewsLanguage(language1);

				}
				for (Term term : newsSource.getTerm()) {
					System.out.println("Source " + term.getContent()
							+ "  Preference " + term.getWeight());

					String sources = term.getContent();
					double weight = term.getWeight();
					NewsSources source1 = new NewsSources();
					source1.setSource(sources);
					source1.setWeight(weight);
					userData.addNewsSources(source1);
				}

				for (int j = 0; j < contextList.size(); j++) {

					NewsContext context = new NewsContext();
					System.out.println("Context Location: "
							+ contextList.get(j).getLocation());
					String location = contextList.get(j).getLocation();
					System.out.println("Context Day: "
							+ contextList.get(j).getDay());
					String day = contextList.get(j).getDay();
					System.out.println("Context  Time: "
							+ contextList.get(j).getTime());
					String time = contextList.get(j).getTime();
					context.setLocationContext(location);
					context.setDayContext(day);
					context.setTimeContext(time);
					userData.addNewsContext(context);

				}

				System.out.println();

				System.out.println("Music Terms");

				System.out.println();

				for (Term term : musicGenre.getTerm()) {
					System.out.println("Genre " + term.getContent()
							+ "  Preference " + term.getWeight());
					String genre1 = term.getContent();
					double weight = term.getWeight();

					MusicGenre genres = new MusicGenre();

					genres.setGenre(genre1);
					genres.setWeight(weight);
					userData.addMusicGenre(genres);					

				}

				// Term term = (Term)country.getTerm();

				for (Term term : musicCountry.getTerm()) {
					System.out.println("Country " + term.getContent()
							+ "  Preference " + term.getWeight());

					String country1 = term.getContent();
					double weight = term.getWeight();

					MusicCountryTerms countryTerms = new MusicCountryTerms();
					countryTerms.setCountry(country1);
					countryTerms.setWeight(weight);
					userData.addMusicCountryTerms(countryTerms);
				}

				for (Term term : musicDuration.getTerm()) {
					System.out.println("Duration " + term.getContent()
							+ " Preference " + term.getWeight());

					String duration1 = term.getContent();
					double weight = term.getWeight();
					MusicDuration musicDurationTerms = new MusicDuration();

					if (duration1.equalsIgnoreCase("long")) {
						musicDurationTerms
								.setDuration(DurationType.LongDuration);
						musicDurationTerms.setWeight(weight);
						userData.addMusicDuration(musicDurationTerms);
					} else if (duration1.equalsIgnoreCase("medium")) {
						musicDurationTerms
								.setDuration(DurationType.MediumDuration);
						musicDurationTerms.setWeight(weight);
						userData.addMusicDuration(musicDurationTerms);

					} else {
						musicDurationTerms
								.setDuration(DurationType.ShortDuration);
						musicDurationTerms.setWeight(weight);
						userData.addMusicDuration(musicDurationTerms);

					}

				}

				for (Term term : musicLanguage.getTerm()) {
					System.out.println("Language " + term.getContent()
							+ "  Preference " + term.getWeight());

					String language1 = term.getContent();
					double weight = term.getWeight();

					MusicLanguage lang = new MusicLanguage();

					lang.setLanguage(language1);
					lang.setWeight(weight);
					userData.addMusicLanguage(lang);

				}

				for (Term term : musicReleaseDate.getTerm()) {
					System.out.println("Release Date range "
							+ term.getContent() + "  Preference "
							+ term.getWeight());

					String releaseDate1 = term.getContent();
					double weight = term.getWeight();
					MusicReleaseDate musicReleaseDateTerms = new MusicReleaseDate();

					if (releaseDate1.equalsIgnoreCase("old")) {
						musicReleaseDateTerms
								.setReleaseDate(ReleaseDateType.Old);
						musicReleaseDateTerms.setWeight(weight);
						userData.addMusicReleaseDate(musicReleaseDateTerms);
					} else if (releaseDate1.equalsIgnoreCase("new")) {
						musicReleaseDateTerms
								.setReleaseDate(ReleaseDateType.New);
						musicReleaseDateTerms.setWeight(weight);
						userData
								.addMusicReleaseDate(musicReleaseDateTerms);

					} else {
						musicReleaseDateTerms
								.setReleaseDate(ReleaseDateType.Medium);
						musicReleaseDateTerms.setWeight(weight);
						userData
								.addMusicReleaseDate(musicReleaseDateTerms);

					}

				}
				

				for (int j = 0; j < musicContextList.size(); j++) {
					MusicContext context = new MusicContext();
					System.out.println("Context Location: "
							+ musicContextList.get(j).getLocation());
					String location = musicContextList.get(j).getLocation();
					System.out.println("Context Day: "
							+ musicContextList.get(j).getDay());
					String day = musicContextList.get(j).getDay();
					System.out.println("Context  Time: "
							+ musicContextList.get(j).getTime());
					String time = musicContextList.get(j).getTime();
					context.setLocationContext(location);
					context.setDayContext(day);
					context.setTimeContext(time);
					
					userData.addMusicContext(context);
;					

				}

				System.out.println();

				System.out.println("Movie Terms");

				System.out.println();

				for (Term term : genre.getTerm()) {
					System.out.println("Genre " + term.getContent()
							+ "  Preference " + term.getWeight());
					movieVector.add(term.getWeight());
					MovieGenre gen = new MovieGenre();
					String genre1 = term.getContent();
					double weight = term.getWeight();
					gen.setGenre(genre1);
					gen.setWeight(weight);
					userData.addMovieGenre(gen);
				}

				// Term term = (Term)country.getTerm();

				for (Term term : country.getTerm()) {
					System.out.println("Country " + term.getContent()
							+ "  Preference " + term.getWeight());
					movieVector.add(term.getWeight());
					MovieCountryTerms countryTerms = new MovieCountryTerms();
					String count = term.getContent();
					double weight = term.getWeight();
					countryTerms.setCountry(count);
					countryTerms.setWeight(weight);
					userData.addMovieCountryTerms(countryTerms);
				}

				for (Term term : duration.getTerm()) {
					System.out.println("Duration " + term.getContent()
							+ " Preference " + term.getWeight());
					movieVector.add(term.getWeight());
					
					String duration1 = term.getContent();
					double weight = term.getWeight();
					MovieDuration movieDurationTerms = new MovieDuration();

					if (duration1.equalsIgnoreCase("long")) {
						movieDurationTerms.setDuration(DurationType.LongDuration);
						movieDurationTerms.setWeight(weight);
						userData.addMovieDuration(movieDurationTerms);
					} else if (duration1.equalsIgnoreCase("medium")) {
						movieDurationTerms
								.setDuration(DurationType.MediumDuration);
						movieDurationTerms.setWeight(weight);
						userData.addMovieDuration(movieDurationTerms);

					} else {
						movieDurationTerms
								.setDuration(DurationType.ShortDuration);
						movieDurationTerms.setWeight(weight);
						userData.addMovieDuration(movieDurationTerms);

					}
					
					
				}

				for (Term term : language.getTerm()) {
					System.out.println("Language " + term.getContent()
							+ "  Preference " + term.getWeight());
					movieVector.add(term.getWeight());
					String language1 = term.getContent();
					double weight = term.getWeight();

					MovieLanguage lang = new MovieLanguage();

					lang.setLanguage(language1);
					lang.setWeight(weight);
					userData.addMovieLanguage(lang);
				}

				for (Term term : releaseDate.getTerm()) {
					System.out.println("Release Date range "
							+ term.getContent() + "  Preference "
							+ term.getWeight());
					movieVector.add(term.getWeight());
					
					String releaseDate1 = term.getContent();
					double weight = term.getWeight();
					MovieReleaseDate movieReleaseDateTerms = new MovieReleaseDate();

					if (releaseDate1.equalsIgnoreCase("new")) {
						movieReleaseDateTerms.setReleaseDate(ReleaseDateType.New);
						movieReleaseDateTerms.setWeight(weight);
						userData.addMovieReleaseDate(movieReleaseDateTerms);
					} else if (releaseDate1.equalsIgnoreCase("medium")) {
						movieReleaseDateTerms.setReleaseDate(ReleaseDateType.Medium);
						movieReleaseDateTerms.setWeight(weight);
						userData.addMovieReleaseDate(movieReleaseDateTerms);

					} else {
						movieReleaseDateTerms.setReleaseDate(ReleaseDateType.Old);
						movieReleaseDateTerms.setWeight(weight);
						userData.addMovieReleaseDate(movieReleaseDateTerms);
				  }
				}

				for (int j = 0; j < contextList.size(); j++) {
					MovieContext context = new MovieContext();
					System.out.println("Context Location: "
							+ contextList.get(j).getLocation());
					
					String location = contextList.get(j).getLocation();
					context.setLocationContext(location);
					System.out.println("Context Day: "
							+ contextList.get(j).getDay());
					String day = contextList.get(j).getDay();
					context.setDayContext(day);
					System.out.println("Context  Time: "
							+ contextList.get(j).getTime());
					String time = contextList.get(j).getTime();
							context.setTimeContext(time);
					userData.addMovieContext(context);

				}			
				
				System.out.println(movieVector);
				System.out.println(movieVector.size());

				System.out.println();
				

				tx.begin();
				em.persist(userData);
				tx.commit();
				//em.close();
				//emf.close();
				System.out.println("Persisted!");

			}

		} catch (JAXBException e) {
			System.out.println(e.toString());
		}finally
		{
			em.close();
			emf.close();
		}
		
		
	}
    


}
