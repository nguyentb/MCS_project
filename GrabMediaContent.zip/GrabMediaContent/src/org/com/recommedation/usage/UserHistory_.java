package org.com.recommedation.usage;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
import org.com.recommendation.jpa.user.User;

@Generated(value="Dali", date="2013-09-02T15:30:25.846+0100")
@StaticMetamodel(UserHistory.class)
public class UserHistory_ {
	public static volatile SingularAttribute<UserHistory, Long> historyId;
	public static volatile SingularAttribute<UserHistory, String> place;
	public static volatile SingularAttribute<UserHistory, String> activity;
	public static volatile SingularAttribute<UserHistory, String> weakday;
	public static volatile SingularAttribute<UserHistory, String> daytime;
	public static volatile SingularAttribute<UserHistory, Boolean> userInside;
	public static volatile SingularAttribute<UserHistory, String> imdbId;
	public static volatile SingularAttribute<UserHistory, User> user;
}
