package org.com.grabmusic;
import java.io.Serializable;

public class TrackArtist  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public String name;
	public String mbId;
	public String url;
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the mbId
	 */
	public String getMbId() {
		return mbId;
	}
	/**
	 * @param mbId the mbId to set
	 */
	public void setMbId(String mbId) {
		this.mbId = mbId;
	}
	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}
	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "artist [name=" + name + ", mbId=" + mbId + ", url=" + url + "]";
	}
	
	
	

}
