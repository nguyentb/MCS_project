package org.com.grabmusic;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;

import org.com.recommendation.jpa.music.MusicDescription;

public class GrabMusic {

	@PersistenceContext
	static EntityManagerFactory emf = Persistence.createEntityManagerFactory("GrabMovies");
	static GenericMusicSearcher<Track> musicSeeker = new MusicSearcher();
	
	static EntityManager em = emf.createEntityManager();
	static EntityTransaction tx = em.getTransaction();	
	
	static Track track = new Track();
	
	static List<Track>musicTracks = new ArrayList<Track>();
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		//String  genre;
		
		Scanner input = new Scanner(System.in);
		System.out.println("Supply the genre of music you want to search...");
		String genre = input.nextLine();
		
		if( genre!=null)
		{
			try {
				
				musicTracks = musicSeeker.findMusicTracks(genre);
				//movies = movieSeeker.findMovies(movieId);
			
				System.out.print("Retrieved music..."+ musicTracks);
				//System.out.println("Retrieved moviess..."+ movies);
			
		} catch (Exception e1) {
			
			System.out.println("nothing was retrieved");
			
			e1.printStackTrace();
			
		} 
			
			for(int i= 0; i<musicTracks.size();i++)
			{
				MusicDescription music = new MusicDescription();
				int rank = musicTracks.get(i).getTrackRank();
				String name = musicTracks.get(i).getTrackName();
				int duration = musicTracks.get(i).getTrackDuration();
				
				String artistName = musicTracks.get(i).getArtist().getName();				
				
				music.setDuration(duration);
				music.setTitle(name);				
				music.setGenre(genre);
				music.setRank(rank);
				music.setName(artistName);
				
				
				// EntityTransaction tx = em.getTransaction();
					
					try {
						tx.begin();
						em.persist(music);
						System.out.println("Music persisted into the DB  " + music);
						tx.commit();						
						System.out.println("Music persisted into the DB");
					} catch (Exception e) {
						
						e.printStackTrace();
				 }
					
				
			}
		
		 

	}
		em.close();
		emf.close();
}
	
}


