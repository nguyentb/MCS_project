package org.com.grabmusic;

import java.io.Serializable;

public class Track implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public TrackArtist artist;
	//public TrackImage image;
	
	public String trackName;
	
	public int trackDuration;
	public String trackUrl;
	
	public int trackRank;
	/**
	 * @return the artist
	 */
	public TrackArtist getArtist() {
		return artist;
	}
	/**
	 * @param artist the artist to set
	 */
	public void setArtist(TrackArtist artist) {
		this.artist = artist;
	}
	
	
	/**
	 * @return the trackName
	 */
	public String getTrackName() {
		return trackName;
	}
	/**
	 * @param trackName the trackName to set
	 */
	public void setTrackName(String trackName) {
		this.trackName = trackName;
	}
	/**
	 * @return the trackDuration
	 */
	public int getTrackDuration() {
		return trackDuration;
	}
	/**
	 * @param trackDuration the trackDuration to set
	 */
	public void setTrackDuration(int trackDuration) {
		this.trackDuration = trackDuration;
	}
	/**
	 * @return the trackUrl
	 */
	public String getTrackUrl() {
		return trackUrl;
	}
	/**
	 * @param trackUrl the trackUrl to set
	 */
	public void setTrackUrl(String trackUrl) {
		this.trackUrl = trackUrl;
	}
	
	/**
	 * @return the trackRank
	 */
	public int getTrackRank() {
		return trackRank;
	}
	/**
	 * @param trackRank the trackRank to set
	 */
	public void setTrackRank(int trackRank) {
		this.trackRank = trackRank;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Track [artist=" + artist + "  trackName="
				+ trackName + ", trackDuration=" + trackDuration
				+ ", trackUrl=" + trackUrl + ", trackRank=" + trackRank + "]";
	}
	
	
	
	

}
