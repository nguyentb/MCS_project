package org.com.grabmusic;

import java.util.ArrayList;
import java.util.Scanner;

public class MusicSearcher extends GenericMusicSearcher<Track>{
	
	//private static final String MOVIE_SEARCH_PATH = "Movie.getInfo/";	
	//private static final String LATEST_MOVIE_PATH = "Movie.getLatest/";
	@Override
	public Track findMusicTrack(String query) {
		Track track = findMusicTrack(query);
		//System.out.println(track);
		return track;
	}	
	
	public  ArrayList<Track> findMusicTracks(String query)
	{
		ArrayList<Track> tracks = retrieveMusicTracks(query);
		//System.out.println(tracks);
		return tracks;		
	}

	
	public ArrayList<Track> retrieveMusicTracks(String query) {
		String url = constructSearchUrl(query);
		System.out.println("URL " +url);
		String response = httpRetriever.retrieve(url);	
		System.out.println("Got  response   " + response);
		//System.out.println("parsed data"  +xmlParser.parseSingleMovieResponse(response) );
		return xmlParser.parseMusicResponse(response);
	}
	
	public static void main(String[] args)
	{
		MusicSearcher searcher = new MusicSearcher();
		Scanner input = new Scanner(System.in);
		System.out.println("Supply the genre of music you want to search...");
		String query = input.nextLine();
		searcher.findMusicTracks(query);
		
		
		
	}

	

}
