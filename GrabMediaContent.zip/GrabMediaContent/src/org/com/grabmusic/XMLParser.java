package org.com.grabmusic;

import java.io.StringReader;
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

public class XMLParser {

	private XMLReader initializeParser() throws ParserConfigurationException, SAXException
	{
		SAXParserFactory factory = SAXParserFactory.newInstance();
		SAXParser parser = factory.newSAXParser();
		
		XMLReader xmlReader = parser.getXMLReader();
		return xmlReader;
		
	}
	
	
	public ArrayList<Track>parseMusicResponse(String xml)
	{
		try {
			XMLReader xmlReader = initializeParser();
			TracksHandler  tracksHandler = new TracksHandler();
			
			 xmlReader.setContentHandler(tracksHandler);
			 xmlReader.parse(new InputSource(new StringReader(xml)));
			// System.out.println("Parsed the data..." + tracksHandler.retrieveTrackList());
			 return tracksHandler.retrieveTrackList();				
			 
		}catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
		
		
	}
	 public Track parseSingleMusiceResponse(String xml) {
			
			try {
				
				XMLReader xmlreader = initializeParser();
				
				TracksHandler tracksHandler = new TracksHandler();

				// assign our handler
				xmlreader.setContentHandler(tracksHandler);
				// perform the synchronous parse
				xmlreader.parse(new InputSource(new StringReader(xml)));
				
				//System.out.println("Parsed the data..." + movieHandler.retrieveMovie());
				
				return tracksHandler.retrieveTrack();	
				
			} 
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
		}
}
