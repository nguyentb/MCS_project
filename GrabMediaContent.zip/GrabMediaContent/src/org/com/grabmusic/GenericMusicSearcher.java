package org.com.grabmusic;

import java.net.URLEncoder;
import java.util.ArrayList;


public abstract class GenericMusicSearcher <E>{
	
	protected static final String BASE_URL = "http://ws.audioscrobbler.com/2.0/?method=";	
	protected static final String METHOD ="tag.gettoptracks&tag=";
	//protected static final String LANGUAGE_PATH = "en/";
	//protected static final String XML_FORMAT = "xml/";
	protected static final String API_KEY = "&api_key=e6868bd9e2bc6502150ade340c945473";
	//protected static final String SLASH = "/";
	
	protected HttpRetriever httpRetriever = new HttpRetriever();
	protected XMLParser xmlParser = new XMLParser();
	
	public abstract Track findMusicTrack(String query);
	public abstract ArrayList<E> findMusicTracks(String query);

	//public abstract String retrieveSearchMethodPath();
	
	@SuppressWarnings("deprecation")
	protected String constructSearchUrl(String query) {
		StringBuffer sb = new StringBuffer();
		sb.append(BASE_URL);
		sb.append(METHOD);	
		sb.append(URLEncoder.encode(query));
		sb.append(API_KEY);		
		
		return sb.toString();
	}

}
