package org.com.grabmusic;

import java.util.ArrayList;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class TracksHandler extends DefaultHandler {

	private ArrayList<Track> trackList;
	private Track musicTrack;
	private ArrayList<TrackImage> trackImagesList;
	private TrackImage trackImage;
	private TrackArtist artist;
	
	private StringBuffer buffer = new StringBuffer();;
	//http://ws.audioscrobbler.com/2.0/?method=tag.gettoptracks&tag=pop&api_key=e6868bd9e2bc6502150ade340c945473
	//boolean track = false;
	boolean inArtist = false;
	
	
	@Override
	public void startElement(String namespaceURI, String localName,	String qName, Attributes atts) throws SAXException {
		
		buffer.setLength(0); 
		
		
	   if (qName.equals("toptracks")) {
			trackList = new ArrayList<Track>();
			
		}
	   else if(qName.equals("track"))
	   {
		   //track = true;
		   musicTrack = new Track();
		   musicTrack.trackRank = Integer.parseInt(atts.getValue("rank"));
	   }
	   else if(qName.equals("artist"))
	   {
		  inArtist = true;
		   artist = new TrackArtist();
		   
	   }	   
		   
	}
	
	@Override
	public void endElement(String uri, String localName, String qName)throws SAXException {	
		
				
		if(qName.equals("track"))
		{
			//track = false;
			trackList.add(musicTrack);
		}
				
		else if (qName.equals("name")) {
			if(inArtist) {
				artist.name = buffer.toString();
			}
			else
			{
				musicTrack.trackName = buffer.toString();
			}
		}
		else if (qName.equals("url")) {
			if(inArtist)
			{
				artist.url = buffer.toString();
			}
			else
			{
				musicTrack.trackUrl = buffer.toString();
			}
		}
		else if(qName.equals("duration"))
		{
			//track.setTrackDuration(Integer.parseInt(buffer.toString()));
			musicTrack.trackDuration = Integer.parseInt(buffer.toString());
		}
		else if(qName.equals("artist"))
		{
			inArtist = false;
			musicTrack.artist = artist;
		}
		
				
	}
	
	@Override
	public void characters(char[] ch, int start, int length) {
		buffer.append(ch, start, length);
	}
		
	public ArrayList<Track> retrieveTrackList() {
		//System.out.println("from handler " + trackList);
		return trackList;
	}
	
	public Track retrieveTrack()
	{
		//System.out.println("from handler " + musicTrack);
		
		return musicTrack;
	}
	
}
	

