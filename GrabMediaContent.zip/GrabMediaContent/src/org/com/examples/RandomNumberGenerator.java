package org.com.examples;

import java.util.Random;
import java.util.Scanner;

public class RandomNumberGenerator {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("What is the minimum number  ");
		Random random;  ;
		int x = sc.nextInt();
		int y = 0;
		do {
		System.out.println("What is the maximum number  ");
		  y = sc.nextInt();
		
		random =  new Random();
		
		double result = x + random.nextInt()*((y-x) + 1);
		
		System.out.println("The result is  " + result/10);
		System.out.println("What is the minimum number  ");
		x = sc.nextInt();
		}while(x!=0);
	}

}
