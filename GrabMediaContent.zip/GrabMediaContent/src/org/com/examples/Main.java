package org.com.examples;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 *
 * @author javadb.com
 */
public class Main {
    
    /**
     * Conversion from a List to a Set, 
     * or from an ArrayList to a HashSet object
     */
    public void convertFromListToSet() {
        
    List fruitsList = new ArrayList ();
        fruitsList.add("Apples");
        fruitsList.add("Bananas");
        fruitsList.add("Oranges");
        fruitsList.add("Grapes");
        fruitsList.add("Grapes");
        fruitsList.add("Bananas");
        
        Set fruitsSet = new HashSet(fruitsList);
        
        for (Object theFruit : fruitsSet)
            System.out.println(theFruit);
        
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new Main().convertFromListToSet();
    }
}