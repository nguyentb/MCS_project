package org.com.recommendation.jpa.music;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-09-02T15:30:26.007+0100")
@StaticMetamodel(MusicGenres.class)
public class MusicGenres_ {
	public static volatile SingularAttribute<MusicGenres, Integer> genresId;
	public static volatile SingularAttribute<MusicGenres, String> genres;
}
