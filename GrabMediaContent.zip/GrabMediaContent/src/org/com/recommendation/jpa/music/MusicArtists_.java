package org.com.recommendation.jpa.music;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-09-02T15:30:26.004+0100")
@StaticMetamodel(MusicArtists.class)
public class MusicArtists_ {
	public static volatile SingularAttribute<MusicArtists, Integer> artistId;
	public static volatile SingularAttribute<MusicArtists, String> firstName;
	public static volatile SingularAttribute<MusicArtists, String> lastName;
	public static volatile SingularAttribute<MusicArtists, String> middleName;
	public static volatile SingularAttribute<MusicArtists, String> name;
}
