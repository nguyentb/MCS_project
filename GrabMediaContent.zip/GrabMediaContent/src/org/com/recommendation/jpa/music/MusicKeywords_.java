package org.com.recommendation.jpa.music;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-09-02T15:30:26.009+0100")
@StaticMetamodel(MusicKeywords.class)
public class MusicKeywords_ {
	public static volatile SingularAttribute<MusicKeywords, Integer> keywordId;
	public static volatile SingularAttribute<MusicKeywords, String> keywords;
}
