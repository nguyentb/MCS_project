package org.com.recommendation.jpa.music;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-09-02T15:30:26.005+0100")
@StaticMetamodel(MusicDescription.class)
public class MusicDescription_ {
	public static volatile SingularAttribute<MusicDescription, Integer> musicId;
	public static volatile SingularAttribute<MusicDescription, String> title;
	public static volatile SingularAttribute<MusicDescription, Integer> duration;
	public static volatile SingularAttribute<MusicDescription, Integer> rank;
	public static volatile SingularAttribute<MusicDescription, String> name;
	public static volatile SingularAttribute<MusicDescription, String> genre;
}
