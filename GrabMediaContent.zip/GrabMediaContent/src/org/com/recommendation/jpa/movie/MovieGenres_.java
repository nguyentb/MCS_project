package org.com.recommendation.jpa.movie;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-09-02T15:30:26.000+0100")
@StaticMetamodel(MovieGenres.class)
public class MovieGenres_ {
	public static volatile SingularAttribute<MovieGenres, Integer> genresId;
	public static volatile SingularAttribute<MovieGenres, String> genres;
	public static volatile SingularAttribute<MovieGenres, MovieDescription> movieDescription;
}
