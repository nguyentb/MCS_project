package org.com.recommendation.jpa.movie;

import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-09-30T00:00:11.799+0100")
@StaticMetamodel(MovieDescription.class)
public class MovieDescription_ {
	public static volatile SingularAttribute<MovieDescription, Integer> movieId;
	public static volatile SingularAttribute<MovieDescription, String> title;
	public static volatile SingularAttribute<MovieDescription, Float> rating;
	public static volatile SingularAttribute<MovieDescription, String> synopsis;
	public static volatile ListAttribute<MovieDescription, MovieArtists> actors;
	public static volatile ListAttribute<MovieDescription, MovieGenres> movieGenres;
	public static volatile ListAttribute<MovieDescription, MovieKeywords> movieKeywords;
}
