package org.com.recommendation.jpa.movie;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-09-02T15:30:26.001+0100")
@StaticMetamodel(MovieKeywords.class)
public class MovieKeywords_ {
	public static volatile SingularAttribute<MovieKeywords, Integer> keywordId;
	public static volatile SingularAttribute<MovieKeywords, String> keywords;
	public static volatile SingularAttribute<MovieKeywords, MovieDescription> movieDescription;
}
