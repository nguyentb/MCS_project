package org.com.recommendation.jpa.movie;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-09-30T00:00:11.793+0100")
@StaticMetamodel(MovieArtists.class)
public class MovieArtists_ {
	public static volatile SingularAttribute<MovieArtists, Integer> starId;
	public static volatile SingularAttribute<MovieArtists, String> name;
	public static volatile SingularAttribute<MovieArtists, MovieDescription> movieDescription;
}
