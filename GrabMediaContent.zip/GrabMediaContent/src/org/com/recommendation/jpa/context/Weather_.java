package org.com.recommendation.jpa.context;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-09-02T15:30:25.993+0100")
@StaticMetamodel(Weather.class)
public class Weather_ {
	public static volatile SingularAttribute<Weather, Integer> weatherId;
	public static volatile SingularAttribute<Weather, String> City;
	public static volatile SingularAttribute<Weather, String> Country;
	public static volatile SingularAttribute<Weather, String> Temperature;
	public static volatile SingularAttribute<Weather, String> Humidity;
	public static volatile SingularAttribute<Weather, String> currentCondition;
	public static volatile SingularAttribute<Weather, String> Code;
	public static volatile SingularAttribute<Weather, String> Date;
	public static volatile SingularAttribute<Weather, String> TemperatureUnit;
	public static volatile SingularAttribute<Weather, String> visibility;
	public static volatile SingularAttribute<Weather, String> windSpeed;
	public static volatile SingularAttribute<Weather, String> windChill;
	public static volatile SingularAttribute<Weather, String> windDirection;
	public static volatile SingularAttribute<Weather, String> sunrise;
	public static volatile SingularAttribute<Weather, String> sunset;
	public static volatile SingularAttribute<Weather, String> pressure;
	public static volatile SingularAttribute<Weather, Location> location;
}
