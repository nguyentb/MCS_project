package org.com.recommendation.jpa.context;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-09-02T15:30:25.990+0100")
@StaticMetamodel(Network.class)
public class Network_ {
	public static volatile SingularAttribute<Network, Integer> networkId;
	public static volatile SingularAttribute<Network, Boolean> isConnectionFast;
	public static volatile SingularAttribute<Network, Integer> connectionSpeed;
	public static volatile SingularAttribute<Network, Integer> ipAddress;
	public static volatile SingularAttribute<Network, Integer> signalLevel;
	public static volatile SingularAttribute<Network, Integer> totalBytesReceieved;
	public static volatile SingularAttribute<Network, Integer> totalBytesTransmitted;
	public static volatile SingularAttribute<Network, Integer> totalPacketsReceieved;
	public static volatile SingularAttribute<Network, Integer> totalPacketsTransmitted;
	public static volatile SingularAttribute<Network, Integer> mobilePaketsRecieved;
	public static volatile SingularAttribute<Network, Integer> mobilePacketsTransmitted;
	public static volatile SingularAttribute<Network, Device> device;
}
