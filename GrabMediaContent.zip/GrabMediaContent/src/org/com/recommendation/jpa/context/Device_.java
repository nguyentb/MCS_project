package org.com.recommendation.jpa.context;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
import org.com.recommendation.jpa.user.User;

@Generated(value="Dali", date="2013-09-02T15:30:25.984+0100")
@StaticMetamodel(Device.class)
public class Device_ {
	public static volatile SingularAttribute<Device, Integer> deviceId;
	public static volatile SingularAttribute<Device, Integer> width;
	public static volatile SingularAttribute<Device, Integer> height;
	public static volatile SingularAttribute<Device, Boolean> batteryLevel;
	public static volatile SingularAttribute<Device, Boolean> storageLevel;
	public static volatile SingularAttribute<Device, Boolean> headsetConnected;
	public static volatile SingularAttribute<Device, Boolean> powerPlugged;
	public static volatile SingularAttribute<Device, User> user;
	public static volatile SingularAttribute<Device, Network> network;
}
