package org.com.recommendation.jpa.context;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
import org.com.recommendation.jpa.user.User;

@Generated(value="Dali", date="2013-09-02T15:30:25.986+0100")
@StaticMetamodel(HighLevelContext.class)
public class HighLevelContext_ {
	public static volatile SingularAttribute<HighLevelContext, Integer> highlevelId;
	public static volatile SingularAttribute<HighLevelContext, String> place;
	public static volatile SingularAttribute<HighLevelContext, String> activity;
	public static volatile SingularAttribute<HighLevelContext, String> weekday;
	public static volatile SingularAttribute<HighLevelContext, String> dayTime;
	public static volatile SingularAttribute<HighLevelContext, Boolean> userInside;
	public static volatile SingularAttribute<HighLevelContext, Boolean> deviceOnUser;
	public static volatile SingularAttribute<HighLevelContext, User> user;
}
