package org.com.recommendation.jpa.context;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
import org.com.recommendation.jpa.user.User;

@Generated(value="Dali", date="2013-09-02T15:30:25.992+0100")
@StaticMetamodel(UserMovement.class)
public class UserMovement_ {
	public static volatile SingularAttribute<UserMovement, Integer> movementId;
	public static volatile SingularAttribute<UserMovement, String> state;
	public static volatile SingularAttribute<UserMovement, Double> speed;
	public static volatile SingularAttribute<UserMovement, Double> bearing;
	public static volatile SingularAttribute<UserMovement, Integer> lastStep;
	public static volatile SingularAttribute<UserMovement, Integer> step;
	public static volatile SingularAttribute<UserMovement, User> user;
}
