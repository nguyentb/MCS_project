package org.com.recommendation.jpa.context;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
import org.com.recommendation.jpa.user.User;

@Generated(value="Dali", date="2013-09-02T15:30:25.988+0100")
@StaticMetamodel(Location.class)
public class Location_ {
	public static volatile SingularAttribute<Location, Integer> addressId;
	public static volatile SingularAttribute<Location, String> address;
	public static volatile SingularAttribute<Location, String> neighbourhood;
	public static volatile SingularAttribute<Location, String> buildingNumber;
	public static volatile SingularAttribute<Location, String> postalCode;
	public static volatile SingularAttribute<Location, Double> latitude;
	public static volatile SingularAttribute<Location, Double> longitude;
	public static volatile SingularAttribute<Location, Integer> locationRadius;
	public static volatile SingularAttribute<Location, Weather> weather;
	public static volatile SingularAttribute<Location, User> user;
}
