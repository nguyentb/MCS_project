package org.com.recommendation.jpa.user;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-09-02T15:30:26.026+0100")
@StaticMetamodel(MusicGenre.class)
public class MusicGenre_ {
	public static volatile SingularAttribute<MusicGenre, Integer> genreId;
	public static volatile SingularAttribute<MusicGenre, String> genre;
	public static volatile SingularAttribute<MusicGenre, Double> weight;
	public static volatile SingularAttribute<MusicGenre, User> user;
}
