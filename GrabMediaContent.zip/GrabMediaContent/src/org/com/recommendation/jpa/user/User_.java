package org.com.recommendation.jpa.user;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-09-30T00:00:11.839+0100")
@StaticMetamodel(User.class)
public class User_ {
	public static volatile SingularAttribute<User, Integer> userId;
	public static volatile SingularAttribute<User, String> firstName;
	public static volatile SingularAttribute<User, String> lastName;
	public static volatile SingularAttribute<User, Integer> age;
	public static volatile SingularAttribute<User, String> gender;
	public static volatile SingularAttribute<User, String> role;
	public static volatile SingularAttribute<User, String> nationality;
	public static volatile SingularAttribute<User, Date> creationDate;
	public static volatile SingularAttribute<User, Integer> YearOfBirth;
	public static volatile ListAttribute<User, MovieContext> movieContext;
	public static volatile ListAttribute<User, MovieGenre> movieGenre;
	public static volatile ListAttribute<User, MovieCountryTerms> movieCountryTerms;
	public static volatile ListAttribute<User, MovieLanguage> movieLanguage;
	public static volatile ListAttribute<User, MovieDuration> movieDuration;
	public static volatile ListAttribute<User, MovieReleaseDate> movieReleaseDate;
	public static volatile ListAttribute<User, MusicContext> musicContext;
	public static volatile ListAttribute<User, MusicGenre> musicGenre;
	public static volatile ListAttribute<User, MusicCountryTerms> musicCountryTerms;
	public static volatile ListAttribute<User, MusicLanguage> musicLanguage;
	public static volatile ListAttribute<User, MusicDuration> musicDuration;
	public static volatile ListAttribute<User, MusicReleaseDate> musicRelease;
	public static volatile ListAttribute<User, NewsSources> newsSource;
	public static volatile ListAttribute<User, NewsScopes> newsScope;
	public static volatile ListAttribute<User, NewsContext> newsContext;
	public static volatile ListAttribute<User, NewsGenre> newsGenre;
	public static volatile ListAttribute<User, NewsCountryTerms> newsCountryTerms;
	public static volatile ListAttribute<User, NewsLanguage> newsLanguage;
	public static volatile ListAttribute<User, NewsDuration> newsDuration;
}
