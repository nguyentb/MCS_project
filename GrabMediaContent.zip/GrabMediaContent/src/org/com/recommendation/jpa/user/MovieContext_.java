package org.com.recommendation.jpa.user;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-09-02T15:30:26.011+0100")
@StaticMetamodel(MovieContext.class)
public class MovieContext_ {
	public static volatile SingularAttribute<MovieContext, Integer> contextId;
	public static volatile SingularAttribute<MovieContext, String> locationContext;
	public static volatile SingularAttribute<MovieContext, String> dayContext;
	public static volatile SingularAttribute<MovieContext, String> timeContext;
	public static volatile SingularAttribute<MovieContext, User> user;
}
