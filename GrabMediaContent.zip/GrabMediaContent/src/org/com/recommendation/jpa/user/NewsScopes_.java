package org.com.recommendation.jpa.user;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-09-02T15:30:26.034+0100")
@StaticMetamodel(NewsScopes.class)
public class NewsScopes_ {
	public static volatile SingularAttribute<NewsScopes, Integer> scopeId;
	public static volatile SingularAttribute<NewsScopes, String> scope;
	public static volatile SingularAttribute<NewsScopes, Double> weight;
	public static volatile SingularAttribute<NewsScopes, User> user;
}
