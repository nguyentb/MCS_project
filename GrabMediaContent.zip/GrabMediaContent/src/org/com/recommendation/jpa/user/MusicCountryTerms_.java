package org.com.recommendation.jpa.user;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-09-02T15:30:26.023+0100")
@StaticMetamodel(MusicCountryTerms.class)
public class MusicCountryTerms_ {
	public static volatile SingularAttribute<MusicCountryTerms, Integer> countryId;
	public static volatile SingularAttribute<MusicCountryTerms, String> country;
	public static volatile SingularAttribute<MusicCountryTerms, Double> weight;
	public static volatile SingularAttribute<MusicCountryTerms, User> user;
}
