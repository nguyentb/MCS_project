package org.com.recommendation.jpa.user;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-09-02T15:30:26.033+0100")
@StaticMetamodel(NewsGenre.class)
public class NewsGenre_ {
	public static volatile SingularAttribute<NewsGenre, Integer> genreId;
	public static volatile SingularAttribute<NewsGenre, String> genre;
	public static volatile SingularAttribute<NewsGenre, Double> weight;
	public static volatile SingularAttribute<NewsGenre, User> user;
}
