package org.com.recommendation.jpa.user;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-09-02T15:30:26.016+0100")
@StaticMetamodel(MovieGenre.class)
public class MovieGenre_ {
	public static volatile SingularAttribute<MovieGenre, Integer> genreId;
	public static volatile SingularAttribute<MovieGenre, String> genre;
	public static volatile SingularAttribute<MovieGenre, Double> weight;
	public static volatile SingularAttribute<MovieGenre, User> user;
}
