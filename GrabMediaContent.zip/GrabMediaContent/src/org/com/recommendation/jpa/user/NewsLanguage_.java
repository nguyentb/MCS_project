package org.com.recommendation.jpa.user;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-09-02T15:30:26.034+0100")
@StaticMetamodel(NewsLanguage.class)
public class NewsLanguage_ {
	public static volatile SingularAttribute<NewsLanguage, Integer> languageId;
	public static volatile SingularAttribute<NewsLanguage, String> language;
	public static volatile SingularAttribute<NewsLanguage, Double> weight;
	public static volatile SingularAttribute<NewsLanguage, User> user;
}
