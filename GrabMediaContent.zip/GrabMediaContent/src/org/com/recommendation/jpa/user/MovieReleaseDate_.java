package org.com.recommendation.jpa.user;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-09-02T15:30:26.020+0100")
@StaticMetamodel(MovieReleaseDate.class)
public class MovieReleaseDate_ {
	public static volatile SingularAttribute<MovieReleaseDate, Integer> releaseDateId;
	public static volatile SingularAttribute<MovieReleaseDate, ReleaseDateType> releaseDate;
	public static volatile SingularAttribute<MovieReleaseDate, Double> weight;
	public static volatile SingularAttribute<MovieReleaseDate, User> user;
}
