package org.com.recommendation.jpa.user;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-09-02T15:30:26.014+0100")
@StaticMetamodel(MovieDuration.class)
public class MovieDuration_ {
	public static volatile SingularAttribute<MovieDuration, Integer> durationId;
	public static volatile SingularAttribute<MovieDuration, DurationType> duration;
	public static volatile SingularAttribute<MovieDuration, Double> weight;
	public static volatile SingularAttribute<MovieDuration, User> user;
}
