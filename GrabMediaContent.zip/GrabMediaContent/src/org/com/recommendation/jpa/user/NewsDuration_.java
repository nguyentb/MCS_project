package org.com.recommendation.jpa.user;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-09-02T15:30:26.032+0100")
@StaticMetamodel(NewsDuration.class)
public class NewsDuration_ {
	public static volatile SingularAttribute<NewsDuration, Integer> durationId;
	public static volatile SingularAttribute<NewsDuration, DurationType> duration;
	public static volatile SingularAttribute<NewsDuration, Double> weight;
	public static volatile SingularAttribute<NewsDuration, User> user;
}
