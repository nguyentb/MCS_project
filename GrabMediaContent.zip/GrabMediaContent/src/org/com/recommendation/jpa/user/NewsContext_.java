package org.com.recommendation.jpa.user;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-09-02T15:30:26.030+0100")
@StaticMetamodel(NewsContext.class)
public class NewsContext_ {
	public static volatile SingularAttribute<NewsContext, Integer> contextId;
	public static volatile SingularAttribute<NewsContext, String> locationContext;
	public static volatile SingularAttribute<NewsContext, String> dayContext;
	public static volatile SingularAttribute<NewsContext, String> timeContext;
	public static volatile SingularAttribute<NewsContext, User> user;
}
