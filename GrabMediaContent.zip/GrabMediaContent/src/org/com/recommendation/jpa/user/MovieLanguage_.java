package org.com.recommendation.jpa.user;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-09-02T15:30:26.018+0100")
@StaticMetamodel(MovieLanguage.class)
public class MovieLanguage_ {
	public static volatile SingularAttribute<MovieLanguage, Integer> languageId;
	public static volatile SingularAttribute<MovieLanguage, String> language;
	public static volatile SingularAttribute<MovieLanguage, Double> weight;
	public static volatile SingularAttribute<MovieLanguage, User> user;
}
