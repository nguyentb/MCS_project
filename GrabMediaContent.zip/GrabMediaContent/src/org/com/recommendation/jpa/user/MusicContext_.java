package org.com.recommendation.jpa.user;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-09-02T15:30:26.021+0100")
@StaticMetamodel(MusicContext.class)
public class MusicContext_ {
	public static volatile SingularAttribute<MusicContext, Integer> contextId;
	public static volatile SingularAttribute<MusicContext, String> locationContext;
	public static volatile SingularAttribute<MusicContext, String> dayContext;
	public static volatile SingularAttribute<MusicContext, String> timeContext;
	public static volatile SingularAttribute<MusicContext, User> user;
}
