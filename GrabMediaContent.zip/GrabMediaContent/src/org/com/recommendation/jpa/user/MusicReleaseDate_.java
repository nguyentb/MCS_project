package org.com.recommendation.jpa.user;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-09-02T15:30:26.029+0100")
@StaticMetamodel(MusicReleaseDate.class)
public class MusicReleaseDate_ {
	public static volatile SingularAttribute<MusicReleaseDate, Integer> releaseDateId;
	public static volatile SingularAttribute<MusicReleaseDate, ReleaseDateType> releaseDate;
	public static volatile SingularAttribute<MusicReleaseDate, Double> weight;
	public static volatile SingularAttribute<MusicReleaseDate, User> user;
}
