package org.com.grabmovies;

import java.io.Serializable;

public class Country implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String name;
	public String code;
	public String url;

}
