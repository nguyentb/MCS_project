package org.com.grabmovies;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;

//import org.com.reco.services.DataService;
import org.com.recommendation.jpa.movie.*;


public class UpdateMoveRating {

	/**
	 * @param args
	 */
	@PersistenceContext
	static EntityManagerFactory emf = Persistence.createEntityManagerFactory("GrabMediaContents");
	static GenericSearcher<Movie> movieSeeker = new MovieSearcher();
	static Movie movi = new Movie();
	static EntityManager em = emf.createEntityManager();
	static EntityTransaction tx = em.getTransaction();	
	static ArrayList<Movie>movies = new ArrayList<Movie>();
	MovieDescription mov = new MovieDescription();
	static List<MovieDescription>movis = new ArrayList<MovieDescription>();
	
	@EJB 
	private static org.com.recommendation.datamodel.DataService data;
	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		
		EntityTransaction tx = em.getTransaction();
		movis = data.getMovieDescription();
		for(MovieDescription m : movis)
		{
			
		}
			
			try {
				tx.begin();
				//movis = (List<MovieDescription>)
				//CriteriaBuilder cr = em.getCriteriaBuilder();
				System.out.println("Movie persisted into the DB");
				tx.commit();
				em.close();
				emf.close();
				
				System.out.println("Movie persisted into the DB");
			} catch (Exception e) {
				
				e.printStackTrace();
			}
	}

}
