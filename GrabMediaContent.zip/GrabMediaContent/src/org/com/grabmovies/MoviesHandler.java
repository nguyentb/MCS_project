/**
 * 
 */
package org.com.grabmovies;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;


import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


/**
 * @author Administrator
 *
 */
public class MoviesHandler extends DefaultHandler{
private StringBuffer buffer;// = new StringBuffer();
	
	private ArrayList<Movie> moviesList;
	private Movie movie;
	private ArrayList<Image> movieImagesList;
	private Image movieImage;
	private ArrayList<Keyword>keywordList;
	private ArrayList<Person>personList;
	private ArrayList<Country>countryList;
	private ArrayList<Category>categoryList;	
	private ArrayList<Studios>studioList;
	private Person person;
	private Keyword keyword;	
	private Country country;
	private Category category;
	private Studios studio;	

    
	@Override
	public void startElement(String namespaceURI, String localName,
			String qName, Attributes atts) throws SAXException {
		
		//buffer.setLength(0);
		buffer = new StringBuffer();
		
	   if (qName.equals("movies")) {
			moviesList = new ArrayList<Movie>();
			
		}
	
		if (qName.equals("movie")) {
			movie = new Movie();
		}
		else if(qName.equals("categories"))
		{
			categoryList = new ArrayList<Category>();
		}
		else if(qName.equals("category"))
		{
			category = new Category();
			category.id = atts.getValue("id");
			
			category.type = atts.getValue("type");
			
			category.name = atts.getValue("name");
			
			category.url = atts.getValue("url");
			
		}
		else if(qName.equals("keywords")){
			keywordList = new ArrayList<Keyword>();
		}
		else if(qName.equals("keyword"))
		{
			keyword = new Keyword();
			keyword.name = atts.getValue("name");
			
		}
		
		
		else if(qName.equals("countries")){
			countryList = new ArrayList<Country>();
			
		}
		else if(qName.equals("country"))
		{
			country = new Country();			
			country.name = atts.getValue("name");
			
			country.code = atts.getValue("code");
			
			country.url = atts.getValue("url");
			
		}
		
		else if (qName.equals("studios"))
		{
			studioList = new ArrayList<Studios>();
		}
		else if(qName.equals("studio"))
		{
			studio = new Studios();
			studio.name = atts.getValue("name");			
			studio.url = atts.getValue("url");
			
		}
				
		else if (qName.equals("images")) {
			movieImagesList = new ArrayList<Image>();
		}
		else if (qName.equals("image")) {
			movieImage = new Image();
			movieImage.type = atts.getValue("type");
			movieImage.url = atts.getValue("url");
			movieImage.size = atts.getValue("size");
			movieImage.width = Integer.parseInt(atts.getValue("width"));
			movieImage.height = Integer.parseInt(atts.getValue("height"));
		}
		else if(qName.equals("cast")){
			personList = new ArrayList<Person>();
			
		}
		else if(qName.equals("person")) {
			person = new Person();
			person.id = atts.getValue("id");
			
			person.name = atts.getValue("name");
			
			person.job = atts.getValue("job");
			
			person.character = atts.getValue("character");
			
			person.order = atts.getValue("order");
			
			person.department = atts.getValue("department");
			
			person.cast_Id = atts.getValue("cast_id");
			
			person.thumb = atts.getValue("thumb");
			person.url = atts.getValue("url");
			
		}
	}
	
	@Override
	public void endElement(String uri, String localName, String qName)throws SAXException {	
		
		
	  if (qName.equals("popularity")) {		 			
		  
		  movie.setPopularity(buffer.toString());
		}
		else if (qName.equals("translated")) {
			movie.setTranslated(Boolean.valueOf(buffer.toString()));
		}
		else if (qName.equals("adult")) {
			movie.setAdult(Boolean.valueOf(buffer.toString())) ;
		}
		else if (qName.equals("language")) {
			movie.setLanguage( buffer.toString());
			
		}
		else if (qName.equals("original_name")) {
			movie.setOriginalName(buffer.toString());
		}
		else if (qName.equals("name")) {
			movie.setName(buffer.toString());
		}
		else if(qName.equals("alternative_name")) {
			movie.setAlternative_name(buffer.toString());
		}
		else if (qName.equals("type")) {
			movie.setType(buffer.toString());
		}
		else if (qName.equals("id")) {
			movie.setId(buffer.toString());
		}
		else if (qName.equals("imdb_id")) {
			movie.setImdbId(buffer.toString());
		}
		else if (qName.equals("url")) {
			movie.setUrl(buffer.toString());
		}
		else if (qName.equals("votes")) {
			movie.setVotes(buffer.toString());
		}
		else if (qName.equals("rating")) {
			movie.setRating(buffer.toString());
		}
		else if (qName.equals("certification")) {
			movie.setCertification(buffer.toString());
		}
		else if (qName.equals("overview")) {
			movie.setOverview(buffer.toString());
		}
		else if (qName.equals("released")) {
			movie.setReleased(buffer.toString());
		}
		else if(qName.equals("runtime"))
		{
			movie.setRuntime(buffer.toString());
		}
		else if (qName.equals("version")) {
			movie.setVersion(buffer.toString());
		}
		else if(qName.equals("trailer"))
		{
			movie.setTrailerUrl(buffer.toString());
		}
		else if (qName.equals("last_modified_at")) {
			movie.setLastModifiedAt(buffer.toString());
		}	
		else if(qName.equals("category"))
		{
			categoryList.add(category);
		}
		else if(qName.equals("categories"))
		{
			movie.categoryList = categoryList;
		}
		else if(qName.equals("keyword"))
		{
			keywordList.add(keyword);
		}
		else if(qName.equals("keywords"))
		{
			movie.keywordList = keywordList;
		}
		else if(qName.equals("studio"))
		{
			studioList.add(studio);
		}
		else if(qName.equals("studios"))
		{
			movie.studioList = studioList;
		}
		
		else if(qName.equals("country"))
		{
			countryList.add(country);
		}
		else if(qName.equals("countries"))
		{
			movie.countryList = countryList;
		}
		else if (qName.equals("image")) {
			movieImagesList.add(movieImage);
		}	
		else if (qName.equals("images")) {
			movie.imagesList = movieImagesList;
		}
		else if(qName.equals("person"))
		{
			
			personList.add(person);
		}
		else if(qName.equals("cast"))
		{
			movie.personList = personList;
		}
		 
		else if (qName.equals("movie")) {
				moviesList.add(movie);
				
			} 	  
	  
		
	}
	
	@Override
	public void characters(char[] ch, int start, int length) {
		if(buffer!=null) {
		
		for (int i=start; i<start+length; i++) {
            buffer.append(ch[i]);
			}
		}
		
		//buffer.append( new String(ch, start, length));		
	}
	
	
	public ArrayList<Movie> retrieveMoviesList() {
		System.out.println("from handler " + moviesList);
		return moviesList;
	}
	
	public Movie retrieveMovie()
	{
		System.out.println("from handler " + moviesList);
		return movie;
	}
	
	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException
	{
		SAXParserFactory factory = SAXParserFactory.newInstance();
		//factory.setNamespaceAware(false);
		SAXParser saxParser = factory.newSAXParser();
		
		//XMLReader xmlReader = saxParser.getXMLReader();
		
		MoviesHandler handler = new MoviesHandler();
		
		//xmlReader.setContentHandler(handler);
	 
		//DefaultHandler handler = new DefaultHandler();
		
		  File file = new File("c:/movies.xml");
	      InputStream inputStream= new FileInputStream(file);
	      Reader reader = new InputStreamReader(inputStream,"UTF-8");	      
	   
	      InputSource is = new InputSource(reader);
	      is.setEncoding("UTF-8");
	      
	     // xmlReader.parse(is);
	      
		   saxParser.parse(is, handler);
		  // ArrayList<Movie> movies = handler.retrieveMoviesList();
		   System.out.println(" Movies " +handler.retrieveMoviesList());
	}
	

}
