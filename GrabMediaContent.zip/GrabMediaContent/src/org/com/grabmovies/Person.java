package org.com.grabmovies;

import java.io.Serializable;

public class Person implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static final String JOB_TYPE="Actor";

	public String job;
	public String name;
	public String id;
	public String character;
	public String department;
	public String thumb;
	public String url;
	public String order;
	public String cast_Id;
	//public static final String JOB_TYPE= "original";
	
	/**
	 * @return the job
	 */
	public String getJob() {
		return job;
	}
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @param job the job to set
	 */
	public void setJob(String job) {
		this.job = job;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the jobType
	 */
	public static String getJobType() {
		return JOB_TYPE;
	}

}
