package org.com.grabmovies;

import java.io.Serializable;

public class Category implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static final String CATEGORY_TYPE="genre";

	public String type;
	public String name;
	public String id;
	public String url;
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Category [name=" + name + "]";
	}
	
	
}
