package org.com.grabmovies;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.com.recommendation.jpa.movie.MovieDescription;

public class DeleMovie {
	
	@PersistenceContext
	static EntityManagerFactory emf = Persistence.createEntityManagerFactory("GrabMovies");

	static EntityManager em = emf.createEntityManager();
	static EntityTransaction tx = em.getTransaction();
	
	private List<MovieDescription>movieList;
	
	public boolean deleteMovieDescription(MovieDescription movie) {
		int key = movie.getMovieId();
		if (em.find(MovieDescription.class, key) != null) {			
			
			em.remove(em.merge(movie));				
			
			return true;
		}
		return false;
	}
	
	public List<MovieDescription> deleteMovieItemUsingTitle(String title) {
		List<MovieDescription> movies = getMovieDescription();
		List<MovieDescription> movis = new ArrayList<MovieDescription>();
		
		for(MovieDescription movie:movies)
		{
			if(movie.getTitle().toString().equalsIgnoreCase(title))
			{
				//movieData.deleteMovieDescription(movie);
				//return movie;
				movis.add(movie);

			}
			else
			{
				if(movie==null)
					throw new RuntimeException("Delete: Movie with " + title +  " not found");
			}			
			
		}
		if(movis!=null) {
		for(int i = 0;i<movis.size()-1; i++)
		{
			try {
				tx.begin();
			deleteMovieDescription(movis.get(i));
			System.out.println(movis.get(i).getMovieId()+"deleted from the DB");
			tx.commit();
			em.close();
			emf.close();
			
			System.out.println(movis.get(i).getMovieId()+"deleted from the DB");
		} catch (Exception e) {
			
			e.printStackTrace();
		}
			
		}
		
	  }
		return movis;
	}
	
	
	public List<MovieDescription> getMovieDescription() {	
		
		Query query =  em.createNamedQuery("findAllMovies");
		movieList = query.getResultList();
		
		return  movieList;
		
	}
	
	public static void main(String[] args) 
	{
		DeleMovie delete = new DeleMovie();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("What is the title of the movie to delete?  ");
		String title = sc.nextLine();
		
		delete.deleteMovieItemUsingTitle(title);
		
		
	
	}
	

}
