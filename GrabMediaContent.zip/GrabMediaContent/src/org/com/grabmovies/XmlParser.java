/**
 * 
 */
package org.com.grabmovies;

import java.io.File;
import java.io.StringReader;
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

/**
 * @author Administrator
 *
 */
public class XmlParser {
	
	private XMLReader initializeParser() throws ParserConfigurationException, SAXException
	{
		SAXParserFactory factory = SAXParserFactory.newInstance();
		SAXParser parser = factory.newSAXParser();
		
		XMLReader xmlReader = parser.getXMLReader();
		return xmlReader;
		
	}
	
	public ArrayList<Movie>parseMovieResponse(String xml)
	{
		try {
			XMLReader xmlReader = initializeParser();
			MoviesHandler moviesHandler = new MoviesHandler();
			
			 xmlReader.setContentHandler(moviesHandler);
			 xmlReader.parse(new InputSource(new StringReader(xml)));
			 System.out.println("Parsed the data..." + moviesHandler.retrieveMoviesList());
			 return moviesHandler.retrieveMoviesList();				
			 
		}catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
		
		
	}
		
	
	 public Movie parseSingleMovieResponse(String xml) {
			
			try {
				
				XMLReader xmlreader = initializeParser();
				
				MoviesHandler moviesHandler = new MoviesHandler();

				// assign our handler
				xmlreader.setContentHandler(moviesHandler);
				// perform the synchronous parse
				xmlreader.parse(new InputSource(new StringReader(xml)));
				
				//System.out.println("Parsed the data..." + movieHandler.retrieveMovie());
				
				return moviesHandler.retrieveMovie();	
				
			} 
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
		}
	 
	 public static void main(String[] args)
	 {
		 //File file = new File("c:/movies.txt");
		 XmlParser parser =  new XmlParser();
		 System.out.println("Parsed data " + parser.parseMovieResponse("c:/movies.xml"));
		 
	 }

}
