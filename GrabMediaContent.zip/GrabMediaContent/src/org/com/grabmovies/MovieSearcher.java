/**
 * 
 */
package org.com.grabmovies;

import java.util.ArrayList;

/**
 * @author Administrator
 *
 */
public class MovieSearcher extends GenericSearcher<Movie> {
	private static final String MOVIE_SEARCH_PATH = "Movie.getInfo/";	
	private static final String LATEST_MOVIE_PATH = "Movie.getLatest/";
	
	public Movie find(String query) {
		Movie movie = retrieveMovie(query);
		System.out.println(movie);
		return movie;
	}	
	
	public  ArrayList<Movie> findMovies(String query)
	{
		ArrayList<Movie> movie = retrieveMovies(query);
		System.out.println(movie);
		return movie;		
	}

	 public Movie retrieveMovie(String query) {
		String url = constructSearchUrl(query);
		System.out.println("URL " +url);
		String response = httpRetriever.retrieve(url);	
		System.out.println("Got  response   " + response);
		//System.out.println("parsed data"  +xmlParser.parseSingleMovieResponse(response) );
		return xmlParser.parseSingleMovieResponse(response);
	}
	
	public ArrayList<Movie> retrieveMovies(String query) {
		String url = constructSearchUrl(query);
		System.out.println("URL " +url);
		String response = httpRetriever.retrieve(url);	
		System.out.println("Got  response   " + response);
		//System.out.println("parsed data"  +xmlParser.parseSingleMovieResponse(response) );
		return xmlParser.parseMovieResponse(response);
	}
	
	public Movie findLatest() {
		String url = constructLatestMovieSearchUrl();
		String response = httpRetriever.retrieve(url);
		return xmlParser.parseSingleMovieResponse(response);
	}

	@Override
	public String retrieveSearchMethodPath() {
		return MOVIE_SEARCH_PATH;
	}
	
	
	
	private String constructLatestMovieSearchUrl() {
		StringBuffer sb = new StringBuffer();
		sb.append(BASE_URL);
		sb.append(LATEST_MOVIE_PATH);
		sb.append(LANGUAGE_PATH);
		sb.append(XML_FORMAT);
		sb.append(API_KEY);
		return sb.toString();
	}	

}
