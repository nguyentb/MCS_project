package org.com.grabmovies;

import java.io.Serializable;
import java.util.ArrayList;

public class Movie implements Serializable {
	
	private static final long serialVersionUID = -6814886315783830255L;
	
	public String popularity;
	public boolean translated;
	public boolean adult;
	public String language;
	public String originalName;
	public String alternative_name;
	public String name;
	public String type;
	public String id;
	public String imdbId;
	public String url;
	public String votes;
	public String rating;
	public String certification;
	public String overview;
	public String released;
	public String version;
	public String runtime;
	public String tagLine;
	public String budget;
	public String revenue;
	public String lastModifiedAt;
	public String trailerUrl;	
	public ArrayList<Image> imagesList = new ArrayList<Image>();
	public ArrayList<Keyword>keywordList  = new ArrayList<Keyword>();
	public ArrayList<Person>personList  = new ArrayList<Person>(); 
	public ArrayList<Country>countryList  = new ArrayList<Country>();
	public ArrayList<Category>categoryList  = new ArrayList<Category>();
	public ArrayList<Studios>studioList  = new ArrayList<Studios>();
	
	public Movie()
	{
		
	}
	
	public String retrieveThumbnail() {
		if (imagesList!=null && !imagesList.isEmpty()) {
			for (Image movieImage : imagesList) {
				if (movieImage.size.equalsIgnoreCase(Image.SIZE_THUMB) &&
						movieImage.type.equalsIgnoreCase(Image.TYPE_POSTER)) {
					return movieImage.url;
				}
			}
		}
		return null;
	}
	
	public String retrieveCoverImage() {
		if (imagesList!=null && !imagesList.isEmpty()) {
			for (Image movieImage : imagesList) {
				if (movieImage.size.equalsIgnoreCase(Image.SIZE_COVER) &&
						movieImage.type.equalsIgnoreCase(Image.TYPE_POSTER)) {
					return movieImage.url;
				}
			}
		}
		return null;
	}
	
	
	/**
	 * @return the popularity
	 */
	public String getPopularity() {
		return popularity;
	}

	/**
	 * @param popularity the popularity to set
	 */
	public void setPopularity(String popularity) {
		this.popularity = popularity;
	}

	/**
	 * @return the translated
	 */
	public boolean isTranslated() {
		return translated;
	}

	/**
	 * @param translated the translated to set
	 */
	public void setTranslated(boolean translated) {
		this.translated = translated;
	}

	/**
	 * @return the adult
	 */
	public boolean isAdult() {
		return adult;
	}

	/**
	 * @param adult the adult to set
	 */
	public void setAdult(boolean adult) {
		this.adult = adult;
	}

	/**
	 * @return the language
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * @param language the language to set
	 */
	public void setLanguage(String language) {
		this.language = language;
	}

	/**
	 * @return the originalName
	 */
	public String getOriginalName() {
		return originalName;
	}

	/**
	 * @param originalName the originalName to set
	 */
	public void setOriginalName(String originalName) {
		this.originalName = originalName;
	}

	/**
	 * @return the alternative_name
	 */
	public String getAlternative_name() {
		return alternative_name;
	}

	/**
	 * @param alternative_name the alternative_name to set
	 */
	public void setAlternative_name(String alternative_name) {
		this.alternative_name = alternative_name;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the imdbId
	 */
	public String getImdbId() {
		return imdbId;
	}

	/**
	 * @param imdbId the imdbId to set
	 */
	public void setImdbId(String imdbId) {
		this.imdbId = imdbId;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * @return the votes
	 */
	public String getVotes() {
		return votes;
	}

	/**
	 * @param votes the votes to set
	 */
	public void setVotes(String votes) {
		this.votes = votes;
	}

	/**
	 * @return the rating
	 */
	public String getRating() {
		return rating;
	}

	/**
	 * @param rating the rating to set
	 */
	public void setRating(String rating) {
		this.rating = rating;
	}

	/**
	 * @return the certification
	 */
	public String getCertification() {
		return certification;
	}

	/**
	 * @param certification the certification to set
	 */
	public void setCertification(String certification) {
		this.certification = certification;
	}

	/**
	 * @return the overview
	 */
	public String getOverview() {
		return overview;
	}

	/**
	 * @param overview the overview to set
	 */
	public void setOverview(String overview) {
		this.overview = overview;
	}

	/**
	 * @return the released
	 */
	public String getReleased() {
		return released;
	}

	/**
	 * @param released the released to set
	 */
	public void setReleased(String released) {
		this.released = released;
	}

	/**
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}

	/**
	 * @return the runtime
	 */
	public String getRuntime() {
		return runtime;
	}

	/**
	 * @param runtime the runtime to set
	 */
	public void setRuntime(String runtime) {
		this.runtime = runtime;
	}

	/**
	 * @return the tagLine
	 */
	public String getTagLine() {
		return tagLine;
	}

	/**
	 * @param tagLine the tagLine to set
	 */
	public void setTagLine(String tagLine) {
		this.tagLine = tagLine;
	}

	/**
	 * @return the budget
	 */
	public String getBudget() {
		return budget;
	}

	/**
	 * @param budget the budget to set
	 */
	public void setBudget(String budget) {
		this.budget = budget;
	}

	/**
	 * @return the revenue
	 */
	public String getRevenue() {
		return revenue;
	}

	/**
	 * @param revenue the revenue to set
	 */
	public void setRevenue(String revenue) {
		this.revenue = revenue;
	}

	/**
	 * @return the lastModifiedAt
	 */
	public String getLastModifiedAt() {
		return lastModifiedAt;
	}

	/**
	 * @param lastModifiedAt the lastModifiedAt to set
	 */
	public void setLastModifiedAt(String lastModifiedAt) {
		this.lastModifiedAt = lastModifiedAt;
	}

	/**
	 * @return the trailerUrl
	 */
	public String getTrailerUrl() {
		return trailerUrl;
	}

	/**
	 * @param trailerUrl the trailerUrl to set
	 */
	public void setTrailerUrl(String trailerUrl) {
		this.trailerUrl = trailerUrl;
	}

	/**
	 * @return the imagesList
	 */
	public ArrayList<Image> getImagesList() {
		return imagesList;
	}

	/**
	 * @param imagesList the imagesList to set
	 */
	public void setImagesList(ArrayList<Image> imagesList) {
		this.imagesList = imagesList;
	}

	/**
	 * @return the keywordList
	 */
	public ArrayList<Keyword> getKeywordList() {
		return keywordList;
	}

	/**
	 * @param keywordList the keywordList to set
	 */
	public void setKeywordList(ArrayList<Keyword> keywordList) {
		this.keywordList = keywordList;
	}

	/**
	 * @return the personList
	 */
	public ArrayList<Person> getPersonList() {
		return personList;
	}

	/**
	 * @param personList the personList to set
	 */
	public void setPersonList(ArrayList<Person> personList) {
		this.personList = personList;
	}

	/**
	 * @return the countryList
	 */
	public ArrayList<Country> getCountryList() {
		return countryList;
	}

	/**
	 * @param countryList the countryList to set
	 */
	public void setCountryList(ArrayList<Country> countryList) {
		this.countryList = countryList;
	}

	/**
	 * @return the categoryList
	 */
	public ArrayList<Category> getCategoryList() {
		return categoryList;
	}

	/**
	 * @param categoryList the categoryList to set
	 */
	public void setCategoryList(ArrayList<Category> categoryList) {
		this.categoryList = categoryList;
	}

	/**
	 * @return the studioList
	 */
	public ArrayList<Studios> getStudioList() {
		return studioList;
	}

	/**
	 * @param studioList the studioList to set
	 */
	public void setStudioList(ArrayList<Studios> studioList) {
		this.studioList = studioList;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Movie [name=");
		builder.append(name);
		builder.append("]");
		return builder.toString();
	}

}
