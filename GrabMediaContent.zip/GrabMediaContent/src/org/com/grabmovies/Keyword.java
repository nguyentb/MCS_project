/**
 * 
 */
package org.com.grabmovies;

import java.io.Serializable;

/**
 * @author Administrator
 *
 */
public class Keyword  implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String name;

}
