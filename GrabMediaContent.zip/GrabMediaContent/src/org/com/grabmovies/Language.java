/**
 * 
 */
package org.com.grabmovies;

import java.io.Serializable;

/**
 * @author Administrator
 *
 */
public class Language implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String code;
	public String name;

}
