
package org.com.grabmovies;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;



public abstract class GenericSearcher <E>{
	
	protected static final String BASE_URL = "http://api.themoviedb.org/2.1/";	
	protected static final String LANGUAGE_PATH = "en/";
	protected static final String XML_FORMAT = "xml/";
	protected static final String API_KEY = "75bad6279b3815c1ff2bcf1bcbe53ca2";
	protected static final String SLASH = "/";
	
	protected HttpRetriever httpRetriever = new HttpRetriever();
	protected XmlParser xmlParser = new XmlParser();
	
	public abstract Movie find(String query);
	public abstract ArrayList<E> findMovies(String query);

	public abstract String retrieveSearchMethodPath();
	
	//@SuppressWarnings("deprecation")
	//@SuppressWarnings("deprecation")
	protected String constructSearchUrl(String query) {
		StringBuffer sb = new StringBuffer();
		sb.append(BASE_URL);
		sb.append(retrieveSearchMethodPath());
		sb.append(LANGUAGE_PATH);
		sb.append(XML_FORMAT);
		sb.append(API_KEY);
		sb.append(SLASH);
		try {
			sb.append(URLEncoder.encode(query, "UTF-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sb.toString();
	}

}
