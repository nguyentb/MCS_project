/**
 * 
 */
package org.com.grabmovies;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import org.com.recommendation.jpa.movie.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
//import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;

/**
 * @author Administrator
 *
 */

public class MovieGrabber {	
	@PersistenceContext(unitName="GrabMediaContent")
	static EntityManagerFactory emf = null;
	static GenericSearcher<Movie> movieSeeker = new MovieSearcher();
	
	static Movie movi = new Movie();
	static ArrayList<Movie>movies = new ArrayList<Movie>();
	static ArrayList<MovieGenres>genres = new ArrayList<MovieGenres>();
	static ArrayList<MovieArtists>artists = new ArrayList<MovieArtists>();
	static ArrayList<MovieKeywords>keys = new ArrayList<MovieKeywords>();	
	//@PersistenceContext
	static EntityManager em = null;	
	static EntityTransaction tx = null;
	
	
	public static void main(String[] args) throws Exception	
	{
		String movieId = "";
		
		emf =  Persistence.createEntityManagerFactory("GrabMediaContent");
		em = emf.createEntityManager();//.createEntityManager();
		tx = em.getTransaction();	
		System.out.println("Supply the movie Id ");	
		
		Scanner sc = new Scanner(System.in);
		//String rating = "";
		
		movieId = sc.nextLine();
		sc.close();
		
		if(movieId!=null)
		{					
			try {					
					movi = movieSeeker.find(movieId);
					//movies = movieSeeker.findMovies(movieId);
				
					System.out.println("Retrieved movie..."+ movi);
					//System.out.println("Retrieved moviess..."+ movies);
				
			} catch (Exception e1) {
				
				System.out.println("nothing was retrieved");
				
				e1.printStackTrace();
			}			
			
			ArrayList<Category>cats = movi.categoryList;			
			ArrayList<Keyword>keywordList = movi.keywordList;
			ArrayList<Person>personList = movi.personList;
			ArrayList<Country>countryList = movi.countryList;
			//ArrayList<Language>languageList = movi.getLanguageList();	
			MovieDescription movie = new MovieDescription();
			
			if(cats!=null) {
			
			for(int i=0; i<cats.size(); i++)
			{
				String genreName = cats.get(i).name.toString();
				MovieGenres genre = new MovieGenres();
				genre.setGenres(genreName);
				movie.addMovieGenres(genre);
				
				}				
			}
			
			if(personList!=null) {				
		
		    for(int i=0; i<2; i++)
			{
				String actorName = personList.get(i).name.toString();				
				MovieArtists act= new MovieArtists();
				act.setName(actorName);
				movie.addMovieArtists(act);				
				act.setName(actorName);
				artists.add(act);
			}
		}			
			if(keywordList!=null) {			
				
			for(int i=0; i<keywordList.size(); i++)
			{
				String keywordName = keywordList.get(i).name.toString();
				MovieKeywords keywords = new MovieKeywords();
				keywords.setKeywords(keywordName);				
				movie.addMovieKeywords(keywords);
				
			  }	
			}
			
			//System.out.println("Genres " +movi.getCategoryList().toString());
			
			//String countryCode = null;			
			//int i = 0;
			
			//countryCode  = countryList.get(i).code;
			//= county.code;
				
			//movie.setActors(artists);
			//movie.setMovieGenres(genres);
			 
			//movie.setMovieKeywords(keys);
			//movie.setCountry(countryCode.toString());
			//movie.setLanguage(languageList.get(0).code.toString());
						
			//movie.setActors(movies.getPersons());
			//movie.setCountry(movie.getCountry());
			Integer runtime=0;
			Date date = null;
			String language = null;
			String synopsis = null;
			String title =null;
			String rating = null ;
			
			String country = null;			
			int i = 0;
				if(countryList!=null) {		
			try {
				country  = countryList.get(i).code;
			} catch (Exception e1) {
				
				e1.printStackTrace();
			}
			
		} 	else
		{
			country ="USA";
		}
			
			if(movi.runtime == null) {
				//return;
				runtime = 90;
				//runtime = Integer.parseInt(movi.runtime);
				//movie.setDuration(runtime);
				 // transaction-type="JTA"
				
			}
			else{
				runtime = Integer.parseInt(movi.runtime);
			}
			if(movi.language!=null) {
				language = movi.language.toString();
			}
			if(movi.rating !=null)
			{
				rating = String.valueOf(movi.getRating());
			}
			if(movi.released!=null) {
				date =converDate(movi.released.toString());
			}
			if(movi.overview!=null) {
				synopsis = movi.overview.toString();
			}
			if(movi.name!=null) {
				title = movi.name.toString();
			}
			 if(country!=null) {
			if(country.equalsIgnoreCase("US"))
			{
				country = "USA";
			}else if(country.equalsIgnoreCase("GB"))
			{
				country = "UK";
			}
			 } else if(country == null)
				 country = "USA";
			
			//movie.setMovieGenres(movies.getGenres());
			// movie = new MovieDescription(title,synopsis,country,date,runtime,language,artists,genres,keys);
			 movie.setMovieId(1004);
			 movie.setTitle(title);
			 movie.setSynopsis(synopsis);
			 movie.setCountry(country);
			 movie.setReleaseDate(date);
			 movie.setDuration(runtime);
			 movie.setLanguage(language);
			 movie.setRating(Float.parseFloat(rating));
			// movie.setRating(Float.parseFloat(rating));
			 
			// movie.addMovieArtists(artists);
			// movie.setActors(artists);
			//.setMovieGenres(genres);
			// movie.setMovieKeywords(keys);
			 
			 //EntityTransaction tx = em.getTransaction();
			
			try {
				tx.begin();
				em.persist(movie);
				System.out.println("Movie persisted into the DB");
				tx.commit();
				em.close();
				emf.close();
				
				System.out.println("Movie persisted into the DB");
			} catch (Exception e) {
				
				e.printStackTrace();
			}

		}
		
	}
	
	public static Date converDate(String date)
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd"); 
	    try {
			Date convertedDate = dateFormat.parse(date);
			return convertedDate;
		} catch (ParseException e) {
			
			e.printStackTrace();
		} 
		
		return null;	
		
	}
	

}
